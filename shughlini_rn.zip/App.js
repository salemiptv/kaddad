import React, { useEffect, useState } from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { StatusBar } from 'expo-status-bar';
import HomeScreen from './screens/HomeScreen';
import ProviderForm from './screens/ProviderForm';
import ResultsScreen from './screens/ResultsScreen';
import AdminScreen from './screens/AdminScreen';
import AsyncStorage from '@react-native-async-storage/async-storage';

const Stack = createNativeStackNavigator();

export default function App() {
  const [providers, setProviders] = useState([]);
  const [users, setUsers] = useState([]);
  const [reports, setReports] = useState([]);
  const [profileData, setProfileData] = useState(null);
  const [adminAuth, setAdminAuth] = useState(false);

  // initialize with sample data (mimic original app)
  useEffect(() => {
    (async () => {
      try {
        const p = await AsyncStorage.getItem('shughlini_providers');
        const u = await AsyncStorage.getItem('shughlini_users');
        const r = await AsyncStorage.getItem('shughlini_reports');
        const prof = await AsyncStorage.getItem('shughlini_profile');
        const admin = await AsyncStorage.getItem('shughlini_admin_auth');

        if (p) setProviders(JSON.parse(p));
        else {
          const initialProviders = [
            { id: 1, name: 'أحمد محمد', phone: '0791234567', city: 'عمان', services: ['سباكة','كهرباء'], rating:4.8, status:'active', registrationDate:'2024-01-15' },
            { id: 2, name: 'خالد علي', phone: '0787654321', city: 'عمان', services: ['دهان','نجارة'], rating:4.5, status:'active', registrationDate:'2024-02-20' }
          ];
          setProviders(initialProviders);
          await AsyncStorage.setItem('shughlini_providers', JSON.stringify(initialProviders));
        }
        if (u) setUsers(JSON.parse(u));
        else {
          const initialUsers = [
            { id:1, name:'سارة أحمد', phone:'0791112222', city:'عمان', registrationDate:'2024-01-10', searches:15 }
          ];
          setUsers(initialUsers);
          await AsyncStorage.setItem('shughlini_users', JSON.stringify(initialUsers));
        }
        if (r) setReports(JSON.parse(r));
        else {
          const initialReports = [];
          setReports(initialReports);
          await AsyncStorage.setItem('shughlini_reports', JSON.stringify(initialReports));
        }
        if (prof) setProfileData(JSON.parse(prof));
        if (admin) setAdminAuth(true);
      } catch (e) {
        console.warn('Init error', e);
      }
    })();
  }, []);

  // save when changed
  useEffect(() => { AsyncStorage.setItem('shughlini_providers', JSON.stringify(providers)); }, [providers]);
  useEffect(() => { AsyncStorage.setItem('shughlini_users', JSON.stringify(users)); }, [users]);
  useEffect(() => { AsyncStorage.setItem('shughlini_reports', JSON.stringify(reports)); }, [reports]);
  useEffect(() => { if (profileData) AsyncStorage.setItem('shughlini_profile', JSON.stringify(profileData)); }, [profileData]);

  return (
    <NavigationContainer>
      <StatusBar style="dark" />
      <Stack.Navigator initialRouteName="Home">
        <Stack.Screen name="Home">
          {props => <HomeScreen {...props} providers={providers} setProviders={setProviders} profileData={profileData} setProfileData={setProfileData} />}
        </Stack.Screen>
        <Stack.Screen name="ProviderForm">
          {props => <ProviderForm {...props} addProvider={(p)=> setProviders(prev=>[...prev,p])} />}
        </Stack.Screen>
        <Stack.Screen name="Results">
          {props => <ResultsScreen {...props} providers={providers} />}
        </Stack.Screen>
        <Stack.Screen name="Admin">
          {props => <AdminScreen {...props} providers={providers} setProviders={setProviders} users={users} setUsers={setUsers} reports={reports} setReports={setReports} adminAuth={adminAuth} setAdminAuth={setAdminAuth} />}
        </Stack.Screen>
      </Stack.Navigator>
    </NavigationContainer>
  );
}