import React, { useState } from 'react';
import { View, Text, Button, TextInput, Picker, StyleSheet, TouchableOpacity, ScrollView } from 'react-native';

const cities = ['','عمان','إربد','الزرقاء','العقبة','مادبا','جرش','عجلون','المفرق','الطفيلة','معان','الكرك','السلط'];

const serviceCategories = [
  { id:'teaching', name:'مهن التدريس', services:['تدريس خصوصي','مراجعة امتحانات'] },
  { id:'medical', name:'المهن الطبية', services:['رعاية منزلية','تمريض منزلي'] },
  { id:'construction', name:'مهن البناء', services:['بلاط','دهان'] },
];

export default function HomeScreen({ navigation, providers, setProviders, profileData }) {
  const [activeTab, setActiveTab] = useState('client');
  const [selectedCity, setSelectedCity] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('');
  const [selectedService, setSelectedService] = useState('');

  const handleSearch = () => {
    navigation.navigate('Results', { city:selectedCity, service:selectedService });
  };

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Text style={styles.title}>شغلني</Text>
      <View style={styles.tabRow}>
        <TouchableOpacity style={[styles.tab, activeTab==='client' && styles.tabActive]} onPress={()=>setActiveTab('client')}>
          <Text style={activeTab==='client' ? styles.tabTextActive : styles.tabText}>للعملاء</Text>
        </TouchableOpacity>
        <TouchableOpacity style={[styles.tab, activeTab==='provider' && styles.tabActive]} onPress={()=>setActiveTab('provider')}>
          <Text style={activeTab==='provider' ? styles.tabTextActive : styles.tabText}>لمقدمي الخدمات</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.tab} onPress={()=> navigation.navigate('Admin')}>
          <Text style={styles.tabText}>الإدارة</Text>
        </TouchableOpacity>
      </View>

      {activeTab !== 'admin' && (
        <View style={styles.hero}>
          <Text style={styles.heroTitle}>{activeTab === 'client' ? 'ابحث عن مقدم الخدمة المناسب' : 'سجّل كمقدم خدمة'}</Text>
          {activeTab === 'client' ? (
            <>
              <Text style={styles.label}>اختر المدينة</Text>
              <Picker selectedValue={selectedCity} onValueChange={(v)=>setSelectedCity(v)} style={styles.picker}>
                {cities.map(c=> <Picker.Item key={c} label={c || 'اختر المدينة'} value={c} />)}
              </Picker>

              <Text style={styles.label}>اختر التصنيف</Text>
              <Picker selectedValue={selectedCategory} onValueChange={(v)=>{setSelectedCategory(v); setSelectedService('');}} style={styles.picker}>
                <Picker.Item label="اختر التصنيف" value=""/>
                {serviceCategories.map(cat => <Picker.Item key={cat.id} label={cat.name} value={cat.id} />)}
              </Picker>

              <Text style={styles.label}>اختر الخدمة</Text>
              <Picker selectedValue={selectedService} onValueChange={(v)=>setSelectedService(v)} enabled={!!selectedCategory} style={styles.picker}>
                <Picker.Item label="اختر الخدمة" value=""/>
                {selectedCategory && serviceCategories.find(c=>c.id===selectedCategory).services.map(s=> <Picker.Item key={s} label={s} value={s} />)}
              </Picker>

              <Button title="بحث" onPress={handleSearch} />
            </>
          ) : (
            <>
              <Text style={{marginBottom:10}}>انضم إلى مقدمي الخدمة لدينا</Text>
              <Button title="سجل كمقدم خدمة" onPress={()=>navigation.navigate('ProviderForm')} />
            </>
          )}
        </View>
      )}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container:{ padding:20, backgroundColor:'#f3f4f6', minHeight: '100%' },
  title:{ fontSize:28, fontWeight:'700', textAlign:'center', marginBottom:20 },
  tabRow:{ flexDirection:'row', justifyContent:'space-around', marginBottom:20 },
  tab:{ paddingVertical:8, paddingHorizontal:12, borderRadius:8, backgroundColor:'#e5e7eb' },
  tabActive:{ backgroundColor:'#2563eb' },
  tabText:{ color:'#111827' },
  tabTextActive:{ color:'#fff' },
  hero:{ backgroundColor:'#fff', padding:16, borderRadius:12 },
  heroTitle:{ fontSize:18, fontWeight:'700', marginBottom:12, textAlign:'center' },
  label:{ marginTop:10, marginBottom:4 },
  picker:{ backgroundColor:'#f9fafb', marginBottom:8 }
});