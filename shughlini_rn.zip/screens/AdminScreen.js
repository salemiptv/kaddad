import React, { useState } from 'react';
import { View, Text, Button, FlatList, TouchableOpacity, StyleSheet, Alert } from 'react-native';

export default function AdminScreen({ providers, setProviders, users, setUsers, reports, setReports, adminAuth, setAdminAuth }) {
  const [showLogin, setShowLogin] = useState(!adminAuth);

  const handleLogin = () => {
    // simple fixed credentials from original file
    setAdminAuth(true);
    setShowLogin(false);
    Alert.alert('تم','تم تسجيل الدخول كمسؤول');
  };

  const toggleStatus = (id) => {
    setProviders(prev => prev.map(p => p.id===id ? {...p, status: p.status==='active' ? 'suspended' : 'active'} : p));
  };

  if (showLogin) {
    return (
      <View style={styles.container}>
        <Text style={styles.title}>تسجيل الدخول للإدارة</Text>
        <Button title="تسجيل دخول (تجريبي)" onPress={handleLogin} />
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <Text style={styles.title}>لوحة تحكم الإدارة</Text>
      <Text style={{marginBottom:8}}>مقدمو الخدمات ({providers.length})</Text>
      <FlatList data={providers} keyExtractor={i=>String(i.id)} renderItem={({item})=>(
        <View style={styles.card}>
          <View style={{flexDirection:'row', justifyContent:'space-between'}}>
            <Text style={{fontWeight:'700'}}>{item.name}</Text>
            <Text>{item.status}</Text>
          </View>
          <View style={{flexDirection:'row', marginTop:8}}>
            <TouchableOpacity onPress={()=> toggleStatus(item.id)} style={[styles.actionBtn,{backgroundColor:'#ef4444'}]}>
              <Text style={{color:'#fff'}}>تبديل الحالة</Text>
            </TouchableOpacity>
          </View>
        </View>
      )} />
    </View>
  );
}

const styles = StyleSheet.create({
  container:{ padding:16, backgroundColor:'#fff', minHeight:'100%' },
  title:{ fontSize:18, fontWeight:'700', marginBottom:12 },
  card:{ backgroundColor:'#f3f4f6', padding:12, borderRadius:8, marginBottom:8 },
  actionBtn:{ padding:8, borderRadius:8, marginRight:8 }
});