import React, { useState } from 'react';
import { View, Text, TextInput, Button, StyleSheet, ScrollView, Alert } from 'react-native';

export default function ProviderForm({ navigation, addProvider }) {
  const [form, setForm] = useState({ name:'', phone:'', email:'', city:'', services:[] });

  const handleSubmit = () => {
    if (!form.name || !form.phone) {
      Alert.alert('خطأ','يرجى ملء الاسم ورقم الهاتف');
      return;
    }
    const newProvider = { ...form, id: Date.now(), status:'pending', registrationDate: new Date().toISOString().split('T')[0], rating:0 };
    addProvider(newProvider);
    Alert.alert('تم','تم إرسال طلب التسجيل. سيتم تفعيل الحساب بعد المراجعة.');
    navigation.navigate('Home');
  };

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <Text style={styles.title}>تسجيل كمقدم خدمة</Text>
      <TextInput placeholder="الاسم الكامل" value={form.name} onChangeText={(t)=>setForm({...form, name:t})} style={styles.input} />
      <TextInput placeholder="رقم الهاتف" value={form.phone} onChangeText={(t)=>setForm({...form, phone:t})} style={styles.input} keyboardType="phone-pad" />
      <TextInput placeholder="البريد الإلكتروني" value={form.email} onChangeText={(t)=>setForm({...form, email:t})} style={styles.input} keyboardType="email-address" />
      <TextInput placeholder="المدينة" value={form.city} onChangeText={(t)=>setForm({...form, city:t})} style={styles.input} />
      <TextInput placeholder="الخدمات (مفصولة بفاصلة)" value={form.services.join(',')} onChangeText={(t)=>setForm({...form, services: t.split(',').map(s=>s.trim())})} style={styles.input} />
      <Button title="إرسال" onPress={handleSubmit} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container:{ padding:20, backgroundColor:'#fff', minHeight:'100%' },
  title:{ fontSize:20, fontWeight:'700', marginBottom:12, textAlign:'center' },
  input:{ borderWidth:1, borderColor:'#e5e7eb', padding:10, borderRadius:8, marginBottom:10 }
});