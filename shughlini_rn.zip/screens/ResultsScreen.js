import React from 'react';
import { View, Text, FlatList, TouchableOpacity, StyleSheet, Linking } from 'react-native';

export default function ResultsScreen({ route, providers }) {
  const { city, service } = route.params || {};

  const filtered = providers.filter(p => 
    (city ? p.city === city : true) && 
    (service ? (p.services || []).includes(service) : true)
  );

  return (
    <View style={styles.container}>
      <Text style={styles.title}>نتائج البحث ({filtered.length})</Text>
      <FlatList 
        data={filtered}
        keyExtractor={(item)=>String(item.id)}
        renderItem={({item}) => (
          <View style={styles.card}>
            <View style={{flexDirection:'row', justifyContent:'space-between'}}>
              <Text style={styles.name}>{item.name}</Text>
              <Text style={styles.rating}>{item.rating || 0} ⭐</Text>
            </View>
            <Text style={styles.city}>المدينة: {item.city}</Text>
            <View style={styles.services}>
              {(item.services||[]).map(s=> <Text key={s} style={styles.serviceBadge}>{s}</Text>)}
            </View>
            <TouchableOpacity style={styles.callBtn} onPress={()=> Linking.openURL(`tel:${item.phone}`)}>
              <Text style={{color:'#fff'}}>اتصال: {item.phone}</Text>
            </TouchableOpacity>
          </View>
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container:{ padding:16, backgroundColor:'#f3f4f6', minHeight:'100%' },
  title:{ fontSize:18, fontWeight:'700', marginBottom:10, textAlign:'center' },
  card:{ backgroundColor:'#fff', padding:12, borderRadius:10, marginBottom:10 },
  name:{ fontSize:16, fontWeight:'700' },
  rating:{ color:'#9a8cfa' },
  city:{ marginTop:6, color:'#374151' },
  services:{ flexDirection:'row', flexWrap:'wrap', gap:6, marginTop:8 },
  serviceBadge:{ backgroundColor:'#e0f2fe', paddingHorizontal:8, paddingVertical:4, borderRadius:6, marginRight:6, marginTop:6 },
  callBtn:{ marginTop:10, backgroundColor:'#10b981', padding:10, borderRadius:8, alignItems:'center' }
});